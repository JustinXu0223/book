#parse("File Header.js")
import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';

// constants
import { theme } from 'constants';

// components
import CommStatusBar from 'components/Layout/CommStatusBar';
import LeftBackIcon from 'components/Layout/LeftBackIcon';
// import { ContainerView } from 'components/Layout/Styles';

const ContainerView = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.pageBackColor};
`;

const ItemText = styled.Text``;

class ${NAME} extends React.Component {
  render() {
    return (
      <ContainerView>
        <CommStatusBar />
        <ItemText>
          ${NAME}
        </ItemText>
      </ContainerView>
    );
  }
}

${NAME}.navigationOptions = ({ navigation }) => ({
  title: '',
  headerLeft: (
    <LeftBackIcon
      onPress={() => navigation.goBack()}
    />
  ),
});

${NAME}.defaultProps = {};

${NAME}.propTypes = {
  navigation: PropTypes.shape({
    dispatch: PropTypes.func,
    goBack: PropTypes.func,
    navigate: PropTypes.func,
    setParams: PropTypes.func,
    getParam: PropTypes.func,
    state: PropTypes.shape({
      key: PropTypes.string,
      routeName: PropTypes.string,
      params: PropTypes.object,
    }),
  }).isRequired,
};

export default ${NAME};