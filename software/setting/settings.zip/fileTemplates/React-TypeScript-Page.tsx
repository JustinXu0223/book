#parse("File Header.js")
import * as React from 'react';

interface ${NAME}Type {
  history: any,
}

class ${NAME} extends React.Component<${NAME}Type> {
  public render() {
    return (
      <div>404</div>
    )
  }
}

export default ${NAME};