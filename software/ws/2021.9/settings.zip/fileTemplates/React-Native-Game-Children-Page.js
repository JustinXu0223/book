#parse("File Header.js")
import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import * as Animatable from 'react-native-animatable';

// constants
import { theme } from 'constants';
import { HOME_DISPLAY_NAME } from 'constants/enum';

const ContainerView = styled(Animatable.View)`
  flex: 1;
  background-color: ${theme.pageBackColor};
`;

const ItemText = styled.Text``;

@Animatable.createAnimatableComponent
class ${NAME} extends React.Component {
  static displayName = HOME_DISPLAY_NAME.activity;
  componentDidMount() {
    console.log('come in activity page');
  }
  componentWillUnmount() {
    console.log('leave the activity page');
  }
  render() {
    const {
      props: {
        currentAnimation,
      },
    } = this;
    return (
      <ContainerView
        animation={currentAnimation}
      >
        <ItemText>
          ${NAME}
        </ItemText>
      </ContainerView>
    );
  }
}


${NAME}.defaultProps = {
  currentAnimation: null,
};

${NAME}.propTypes = {
  currentAnimation: PropTypes.string,
};

export default ${NAME};