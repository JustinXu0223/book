import React from 'react';

interface ${NAME}Props {
  [random: string]: any;
}

interface ${NAME}State {
  [random: string]: any;
}

const ${NAME} = ({}: ${NAME}PropsType) => {
  return (
    <div>${NAME}</div>
  );
}


export default ${NAME};
