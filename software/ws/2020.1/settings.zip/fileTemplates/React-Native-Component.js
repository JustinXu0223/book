#parse("File Header.js")
import React from 'react';
// import PropTypes from 'prop-types';
import styled from 'styled-components';

// constants
import { theme } from 'constants';

const ContainerView = styled.View``;
const ItemText = styled.Text``;

class ${NAME} extends React.PureComponent {
  render() {
    return (
      <ContainerView>
        <ItemText>
          ${NAME}
        </ItemText>
      </ContainerView>
    );
  }
}

${NAME}.defaultProps = {};

${NAME}.propTypes = {};

export default ${NAME};