import React from 'react';

interface ${NAME}Props {
  [random: string]: any;
}

interface ${NAME}State {
  [random: string]: any;
}

class ${NAME} extends React.PureComponent<${NAME}PropsType, ${NAME}StateType> {
  public static defaultProps = {};
  
  public state = {};
  
  public render() {
    return (
      <div>${NAME}</div>
    );
  }
}

export default ${NAME};