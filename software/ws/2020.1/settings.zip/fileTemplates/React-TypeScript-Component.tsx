#parse("File Header.js")
import * as React from 'react';

interface ${NAME}PropsType {
  [random: string]: any;
}

class ${NAME} extends React.PureComponent<${NAME}PropsType> {
  public render() {
    return (
      <div>404</div>
    )
  }
}

export default ${NAME};