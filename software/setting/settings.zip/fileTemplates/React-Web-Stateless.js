#parse("File Header.js")
import React from 'react';
// import PropTypes from 'prop-types';

const ${NAME} = () => {
  return (
    <div>${NAME}</div>
  );
}

${NAME}.defaultProps = {};

${NAME}.propTypes = {};

export default ${NAME};
